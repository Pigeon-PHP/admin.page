let server = "http://localhost:8080"
let jwt = "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI2ZjVhZjIwYmYxMDk1MGZhYTVkZmM1NDc4Y2Q0Y2ZiYSIsInN1YiI6IjY0OTA3OTk0NTU5ZDIyMDBjNTc3ZDM0MCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.g7OKZiJ7GmZzkOWlNjqxo0GgG9b4uvlVK4akV4N-L9Y"
let imgServer = "https://image.tmdb.org/t/p/original/"
let imgServer2 = "https://image.tmdb.org/t/p/w500/"
